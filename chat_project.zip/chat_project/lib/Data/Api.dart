

import 'dart:developer';

import 'package:chat_project/models/chat_user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';

import '../models/message.dart';

class Api{
  static FirebaseFirestore firestore = FirebaseFirestore.instance;
  static FirebaseAuth auth= FirebaseAuth.instance;
  static late ChatUser me;
  static User get user => auth.currentUser!;
  TextEditingController textcontroller = new TextEditingController();
  static Future<bool> userExists(Map<String,dynamic> userInfoMap) async {////////
    return (await firestore.
    collection('users')
        .doc(user.uid)
        .get())
        // .set(selfInfoMap()))SelfInfoMap
        .exists;
  }

  // static Future<bool> userExists() async {
  //   return (await firestore.
  //   collection('users')
  //       .doc(user.uid)
  //       .get())
  //       .exists;
  // }
  static Future<void> getSelfInfo() async {
    await firestore.collection('users').doc(user.uid)
        // .where('name', isEqualTo:user).snapshots()
        .get().then((user) async {
      if (user.exists) {
        // me = ChatUser.fromJson(user.data()!);
        // await getFirebaseMessagingToken();
        //
        // //for setting user status to active
        // APIs.updateActiveStatus(true);
        // log('My Data: ${user.data()}');
      } else {
        await createUser().then((value) => getSelfInfo());
      }
    });
  }
  static Stream<QuerySnapshot<Map<String, dynamic>>> getAllUsers(){
    //   List<String> userIds) {
    // log('\nUserIds: $userIds');

    return firestore
        .collection('users')
        .where('id', isNotEqualTo:user.uid).snapshots();
        // whereIn: userIds.isEmpty
        //     ? ['']
        //     : userIds)
        // .snapshots();
  }
//because empty list throws an error
  // .where('id', isNotEqualTo: user.uid)

  static Future<void> createUser() async {
    final time = DateTime.now().millisecondsSinceEpoch.toString();
    final chatUser= ChatUser(
      id:user.uid , name: user.displayName.toString(),
      email: user.email.toString(),
    about: "Hey, i'm using Let's Talk.",
    image: user.photoURL.toString(),
    createdAt: time,
    isOnline: false,
    lastActive: time ,
    pushToken: "",
  );
    return await firestore
          .collection('users')
          .doc(user.uid)
          .set(chatUser.toJson());
  }
  static Stream<QuerySnapshot<Map<String, dynamic>>> getUserInfo(
      ChatUser chatUser) {
    return firestore
        .collection('users')
        .where('id', isEqualTo: chatUser.id)
    .where("name", isEqualTo: user)
        .snapshots();
  }

  static Stream<QuerySnapshot<Map<String, dynamic>>> getMyUsersId() {
    return firestore
        .collection('users')
        .doc(user.uid)
        .collection('my_users')
        .snapshots();
  }

  static String getConversationID(String id) => user.uid.hashCode <= id.hashCode
      ? '${user.uid}_$id'
      : '${id}_${user.uid}';


  static Stream<QuerySnapshot<Map<String, dynamic>>> getAllmessages(ChatUser user){
    //   List<String> userIds) {
    // log('\nUserIds: $userIds');

    return firestore
        .collection('chats/${getConversationID(user.id)}/messages/')
        .snapshots();
    // whereIn: userIds.isEmpty
    //     ? ['']
    //     : userIds)
    // .snapshots();
  }
  static Future<void> sendMessage(
      ChatUser chatUser, String msg) async {
    //message sending time (also used as id)
    final time = DateTime.now().millisecondsSinceEpoch.toString();

    //message to send
    final Message message = Message(
        told: chatUser.id,
        msg: msg,
        read: '',
        type: Type.text,
        formId: user.uid,
        sent: time);
    //
    final ref = firestore
        .collection('chats/${getConversationID(chatUser.id)}/messages/');
    await ref.doc(time).set(message.toJson()
    // ).then((value)=>
    //     sendPushNotification(chatUser, type == Type.text ? msg : 'image')
    );
  }
  Future DeleteUserData(String id)async{
    return await FirebaseFirestore.instance.collection("users").doc(id).delete();
  }



  // searchUser(String name) async {
  //   QuerySnapshot querySnapshot = await Api.getthisUserInfo(name);
  //
  //   id = querySnapshot.docs[0].id;
  //
  //   setState(() {});
  // }

}






