// // import 'package:firebase_chat/common/store/store.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// // import 'package:get/get.dart';
// // import 'package:firebase_chats/';
//
// class ContactController extends GetxController{
//
// }
