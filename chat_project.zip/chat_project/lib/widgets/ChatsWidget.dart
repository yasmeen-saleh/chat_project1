// import 'dart:js';

import 'package:chat_project/screens/ChatPage.dart';
import 'package:chat_project/screens/chat.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
class ChatsWidget extends StatelessWidget{
  Widget build(BuildContext context){
    return SingleChildScrollView(

      child: Padding(
        padding: EdgeInsets.symmetric(
            horizontal: 15,
            vertical: 5),
        child: Column(
          children: [
            for(int i=1; i<10 ;i++)
              chatBuilder(chatName: "Programmer", lastMessage: "How are you? ", avatar: "images/profile$i.jpeg", context: context) //TODO check why it's not accepting the method of $i
          ],
        ),
      ),
    );
  }
}



 InkWell chatBuilder({required String chatName, required String lastMessage,required String avatar,required BuildContext context})
{
  return InkWell(
    onTap: (){
      Navigator.push(context,MaterialPageRoute(
          builder: (context)=> ChatPage()));
    },
    child: Container(
      margin: EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(40),
            child: Image.asset( avatar, height: 65,width:65 ,
              fit: BoxFit.cover,),//Todo can i make it a string for path

          ),
          Padding(
            padding: EdgeInsets.only(left:20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(chatName//TODO make it a varible that has he name of the person he is chatting with+ make component
                    , style:TextStyle( fontSize: 18,fontWeight: FontWeight.bold ) ),
                SizedBox(
                  height: 3,
                ),
                Text(lastMessage//TODO make it a varible that has he chat of the person he is chatting with+ make component
                    , style:TextStyle( fontSize: 15,fontWeight: FontWeight.w500 , color: Colors.black26) )

              ],
            ),

          ),
          Spacer()
          ,Column(
            children: [
              Text("12:18PM",//TODO make it vareible
              style: TextStyle(
                color: Colors.purple[800],
                fontSize: 15,
                fontWeight: FontWeight.w500,
              ),
              ), SizedBox(
                height: 6,
              ),
              Container(
                alignment: Alignment.center,
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: Colors.purple[800],
                  borderRadius: BorderRadius.circular(20)
                ),child: (
              Text(
                "2" ,//TODO put a varible for the number of messages in a vhat
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  color: Colors.white,
                  fontSize: 16
                ),

              )
              ),


              )

            ],
          )


        ],
      ),
    ),
  );
}










// InkWell(
//   onTap: (){
//   },
//   child: Container(
//     margin: EdgeInsets.symmetric(vertical: 12),
//     child: Row(
//       children: [
//         ClipRRect(
//           borderRadius: BorderRadius.circular(40),
//           child: Image.asset("images/profile.jpeg" , height: 65,width:65 ,),//Todo add profile image
//
//         ),
//         Padding(
//             padding: EdgeInsets.only(left:20),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text("Programmer"//TODO make it a verible that has he name of the person he is chatting with+ make component
//                   , style:TextStyle( fontSize: 18,fontWeight: FontWeight.bold ) ),
//               SizedBox(
//                 height: 3,
//               ),
//               Text("Hi, how are you"//TODO make it a verible that has he chat of the person he is chatting with+ make component
//                   , style:TextStyle( fontSize: 15,fontWeight: FontWeight.w500 , color: Colors.black26) )
//
//             ],
//           ),
//
//         ),
//
//
//       ],
//     ),
//   ),
// ),