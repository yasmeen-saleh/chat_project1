// import 'package:flutter/services.dart';
import 'dart:convert';
import 'dart:developer';
import 'package:chat_project/Data/Api.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:chat_project/screens/ChatPage.dart';
import 'package:chat_project/screens/chat.dart';
import 'package:chat_project/widgets/chat_user_card.dart';
import 'package:flutter/cupertino.dart';
// import 'package:chat_project/screens/chat.dart';
// import 'package:flutter/widgets.dart';
import 'package:flutter/material.dart';
import 'package:chat_project/models/chat_user.dart';
import '../Data/Api.dart';

class ChatsWidget extends StatefulWidget{
  @override
  State<ChatsWidget> createState() => _ChatsWidgetState();
}

class _ChatsWidgetState extends State<ChatsWidget> {
  List<ChatUser> list=[];
  void initState(){
    super.initState();
    Api.getSelfInfo();
  }
  Widget build(BuildContext context){
    return Scaffold(

      floatingActionButton: FloatingActionButton(

        onPressed: (){

        },
        backgroundColor: Colors.purple[800],
        child: Icon(Icons.message, color: Colors.white),

      ),
        // firestore.collection('users').snapshots()
      body:StreamBuilder(
        stream: Api.getAllUsers(),
          // snapshot.data?.docs.map((e) => e.id).toList() ?? []
        builder: (context, snapshot) {
          switch(snapshot.connectionState){
            //data is loading
            case ConnectionState.waiting:
            case ConnectionState.none:
              return const Center(child: CupertinoActivityIndicator(color: Colors.purple,),); //todo change it to match the one in the front page
              //data is loaded
            case ConnectionState.active:
            case ConnectionState.done:

              final data = snapshot.data?.docs;
              list =data?.map((e) => ChatUser.fromJson(e.data())).toList() ?? [];
                // log('Data: ${jsonEncode( i.data())}');//todo find what is the problem
                // list.add(i.data()['name']);//its not returnning data
              if(list.isNotEmpty){
                return ListView.builder(
                    itemCount: list.length,
                    padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                    physics: const BouncingScrollPhysics(),
                    itemBuilder: (context , index){
                      return ChatUserCard(user:list[index]);
                      // chatBuilder(chatName: "Programmer", lastMessage: "How are you? ", avatar: "images/profile.jpeg", context: context);
                    }

                );

              }else{
                return Center(child: Text("No Internet Connection! ", style: TextStyle(  fontSize: 20), textAlign: TextAlign.center));
              }


            }
          }
    )
    );
  }
}

// class chatBuilder {
//   InkWell chatBuilderr({required String chatName, required String lastMessage,required String avatar,required BuildContext context})
//   {
//     return InkWell(
//       onTap: (){
//         Navigator.push(context,MaterialPageRoute(
//             builder: (context)=> ChatPage(user: widget.user)));
//       },
//       child: Container(
//         margin: EdgeInsets.symmetric(vertical: 12),
//         child: Row(
//           children: [
//             ClipRRect(
//               borderRadius: BorderRadius.circular(40),
//               child: Image.asset( avatar, height: 65,width:65 ,
//                 fit: BoxFit.cover,),//Todo can i make it a string for path
//
//             ),
//             Padding(
//               padding: EdgeInsets.only(left:20),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.start,
//                 children: [
//                   Text(chatName//TODO make it a varible that has he name of the person he is chatting with+ make component
//                       , style:TextStyle( fontSize: 18,fontWeight: FontWeight.bold ) ),
//                   SizedBox(
//                     height: 3,
//                   ),
//                   Text(lastMessage//TODO make it a varible that has he chat of the person he is chatting with+ make component
//                       , style:TextStyle( fontSize: 15,fontWeight: FontWeight.w500 , color: Colors.black26) )
//
//                 ],
//               ),
//
//             ),
//             Spacer()
//             ,Column(
//               children: [
//                 Text("12:18PM",//TODO make it vareible
//                   style: TextStyle(
//                     color: Colors.purple[800],
//                     fontSize: 15,
//                     fontWeight: FontWeight.w500,
//                   ),
//                 ), SizedBox(
//                   height: 6,
//                 ),
//                 Container(
//                   alignment: Alignment.center,
//                   width: 28,
//                   height: 28,
//                   decoration: BoxDecoration(
//                       color: Colors.purple[800],
//                       borderRadius: BorderRadius.circular(20)
//                   ),child: (
//                     Text(
//                       "2" ,//TODO put a varible for the number of messages in a vhat
//                       style: TextStyle(
//                           fontWeight: FontWeight.w500,
//                           color: Colors.white,
//                           fontSize: 16
//                       ),
//
//                     )
//                 ),
//
//
//                 )
//
//               ],
//             )
//
//
//           ],
//         ),
//       ),
//     );
//   }
// }












// SingleChildScrollView(
//
//   floatingActionButton: FloatingActionButton(
//
//     onPressed: (){
//
//     },
//     backgroundColor: Colors.purple[800],
//     child: Icon(Icons.message, color: Colors.white),
//
//   ),
// child: StreamBuilder<Object>(
//   builder: (context, snapshot) {
//     return ListView.builder(
//     itemCount: 16,
//     padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
//     itemBuilder: (context , index){
//       return chatBuilder(chatName: "Programmer", lastMessage: "How are you? ", avatar: "images/profile.jpeg", context: context);
//     }
//
//     );
//
//   }
//   )
// );

// $i


// Padding( //TODO maybe you have to change it to listview.builder
// padding: EdgeInsets.symmetric(
// horizontal: 15,
// vertical: 5),
// child: Column(
// children: [
// // for(int i=1; i<10 ;i++)
// chatBuilder(chatName: "Programmer", lastMessage: "How are you? ", avatar: "images/profile.jpeg", context: context) //TODO check why it's not accepting the method of $i
// ],
// ),
// )



// InkWell(
//   onTap: (){
//   },
//   child: Container(
//     margin: EdgeInsets.symmetric(vertical: 12),
//     child: Row(
//       children: [
//         ClipRRect(
//           borderRadius: BorderRadius.circular(40),
//           child: Image.asset("images/profile.jpeg" , height: 65,width:65 ,),//Todo add profile image
//
//         ),
//         Padding(
//             padding: EdgeInsets.only(left:20),
//           child: Column(
//             crossAxisAlignment: CrossAxisAlignment.start,
//             children: [
//               Text("Programmer"//TODO make it a verible that has he name of the person he is chatting with+ make component
//                   , style:TextStyle( fontSize: 18,fontWeight: FontWeight.bold ) ),
//               SizedBox(
//                 height: 3,
//               ),
//               Text("Hi, how are you"//TODO make it a verible that has he chat of the person he is chatting with+ make component
//                   , style:TextStyle( fontSize: 15,fontWeight: FontWeight.w500 , color: Colors.black26) )
//
//             ],
//           ),
//
//         ),
//
//
//       ],
//     ),
//   ),
// ),