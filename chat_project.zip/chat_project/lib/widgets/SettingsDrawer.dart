import 'package:flutter/material.dart';
class SettingDrawer extends StatelessWidget{
  Widget build(BuildContext context){
    return Drawer(
          child: ListView(
            children: [
              DrawerHeader(child: Image.asset("images/BlankProfile.png"))
              , ListTile(
                  leading: Icon(Icons.account_box),
                  title: Text(
                      "Change profile Image"
                  ),
                  onTap: (){

                  }

              ),ListTile(
                  leading: Icon(Icons.account_box),
                  title: Text(
                      "LOG OUT"
                  ),

                  onTap: (){
                  }
              )
            ],
          ),


    ) ;
  }

}






