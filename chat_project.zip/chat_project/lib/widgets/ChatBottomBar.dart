// import 'package:flutter/material.dart';
//
// import '../Data/Api.dart';
// import '../models/chat_user.dart';
// class ChatBottomBar extends StatefulWidget{
//   final ChatUser user;
//   const ChatBottomBar({super.key, required this.user});
//   @override
//   State<ChatBottomBar> createState() => _ChatBottomBarState();
// }
// final _textController = TextEditingController();
// class _ChatBottomBarState extends State<ChatBottomBar> {
//   // final _textController = TextEditingController();
//   Widget build(BuildContext context){
//     return ChatInput(widget.user,_textController.text);
//       // chatInput(
//     //   child: Container(
//     //     height: 65,
//     //     child: Row(
//     //       children: [
//     //       Container(
//     //         margin: EdgeInsets.all(5),
//     //         padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
//     //         decoration: BoxDecoration(
//     //           color: Colors.white,
//     //           borderRadius: BorderRadius.circular(20)
//     //         ),
//     //         child: Row(
//     //           children: [
//     //             // Icon(Icons.)
//     //           SizedBox(width: 10,),
//     //             Container(
//     //               alignment: Alignment.center,
//     //               width:290,
//     //               child: Expanded(
//     //                 child: TextField(
//     //                   keyboardType: TextInputType.multiline,
//     //                   maxLines: null,
//     //                   style: TextStyle(
//     //                     fontSize: 16,
//     //                   ),
//     //                   decoration: InputDecoration(
//     //
//     //                     hintText: "write your message here....",
//     //                     hintStyle: TextStyle(fontSize: 16),
//     //                     border: InputBorder.none,
//     //
//     //                   ),
//     //                 ),
//     //               ),
//     //             ),
//     //             TextButton(onPressed:(){
//     //
//     //             }, child: Text(
//     //               'send',
//     //               style: TextStyle(
//     //                   color: Colors.deepPurple,
//     //                   fontWeight: FontWeight.bold,
//     //                   fontSize: 18
//     //               ),
//     //             ),
//     //             )
//     //
//     //           ],
//     //         ),
//     //       )
//     //       ],
//     //     ),
//     //   ),
//     // );
//   }
// }
//
//
//  Widget ChatInput(ChatUser user, String text){
// return Container(
// height: 65,
// child: Row(
// children: [
// Container(
// margin: EdgeInsets.all(5),
// padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
// decoration: BoxDecoration(
// color: Colors.white,
// borderRadius: BorderRadius.circular(20)
// ),
// child: Row(
// children: [
// // Icon(Icons.)
// SizedBox(width: 10,),
// Container(
// alignment: Alignment.center,
// width:290,
// child: Expanded(
// child: TextField(
// controller: _textController,
// keyboardType: TextInputType.multiline,
// maxLines: null,
// style: TextStyle(
// fontSize: 16,
// ),
// decoration: InputDecoration(
//
// hintText: "write your message here....",
// hintStyle: TextStyle(fontSize: 16),
// border: InputBorder.none,
//
// ),
// ),
// ),
// ),
// TextButton(onPressed:(){
// if (_textController.text.isNotEmpty){
//   Api.sendMessage(widget.user, _textController.text);
//   _textController.text = "";
// }
// }, child: Text(
// 'send',
//
// style: TextStyle(
// color: Colors.deepPurple,
// fontWeight: FontWeight.bold,
// fontSize: 18
// ),
// ),
// )
//
// ],
// ),
// )
// ],
// ),
// );
// }
//
//
// // //todo here we will add the message sending funcation
// // Container(
// // decoration: BoxDecoration(
// // border: Border(
// // top: BorderSide(
// // color: Colors.deepPurple,
// // width: 2,
// //
// // )
// // )
// // ),
// // child:Row(
// // crossAxisAlignment: CrossAxisAlignment.center,
// // children: [
// // Expanded(child: TextField(
// // onChanged: (value){
// //
// // },
// // decoration: InputDecoration(
// // contentPadding: EdgeInsets.symmetric(
// // vertical: 10,
// // horizontal: 20,
// // ),
// // hintText: "write your message here....",
// // border: InputBorder.none)
// // ),
// // ),
// // TextButton(onPressed:(){}, child: Text(
// // 'send',
// // style: TextStyle(
// // color: Colors.deepPurple,
// // fontWeight: FontWeight.bold,
// // fontSize: 18
// // ),
// // ))
// //
// // ],
// // )
// // ,
// // )
// // ;