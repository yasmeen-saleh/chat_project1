import 'package:flutter/material.dart';
class ChatBottomBar extends StatelessWidget{
  Widget build(BuildContext context){
    return Container(
      height: 65,
      child: Row(
        children: [
        Container(
          margin: EdgeInsets.all(5),
          padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20)
          ),
          child: Row(
            children: [
              // Icon(Icons.)
            SizedBox(width: 10,),
              Container(
                alignment: Alignment.center,
                width:290,
                child: TextFormField(
                  style: TextStyle(
                    fontSize: 18,
                  ),
                  decoration: InputDecoration(
                    hintText: "write your message here....",
                    hintStyle: TextStyle(fontSize: 16),
                    border: InputBorder.none,

                  ),
                ),
              ),
              TextButton(onPressed:(){

              }, child: Text(
                'send',
                style: TextStyle(
                    color: Colors.deepPurple,
                    fontWeight: FontWeight.bold,
                    fontSize: 18
                ),
              ),
              )

            ],
          ),
        )
        ],
      ),
    );
  }
}





// //todo here we will add the message sending funcation
// Container(
// decoration: BoxDecoration(
// border: Border(
// top: BorderSide(
// color: Colors.deepPurple,
// width: 2,
//
// )
// )
// ),
// child:Row(
// crossAxisAlignment: CrossAxisAlignment.center,
// children: [
// Expanded(child: TextField(
// onChanged: (value){
//
// },
// decoration: InputDecoration(
// contentPadding: EdgeInsets.symmetric(
// vertical: 10,
// horizontal: 20,
// ),
// hintText: "write your message here....",
// border: InputBorder.none)
// ),
// ),
// TextButton(onPressed:(){}, child: Text(
// 'send',
// style: TextStyle(
// color: Colors.deepPurple,
// fontWeight: FontWeight.bold,
// fontSize: 18
// ),
// ))
//
// ],
// )
// ,
// )
// ;