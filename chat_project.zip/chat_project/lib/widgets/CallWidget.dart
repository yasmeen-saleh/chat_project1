import 'package:flutter/material.dart';
class CallWidget extends StatelessWidget{
  Widget build(BuildContext context){
    return SingleChildScrollView(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 15,vertical: 5),
        child: Column(
          children: [
            for( int i = 1; i<7; i++)
              calls(callerName: "Yasmeen", callDate: " Today, 12:39", callerAvatar: "images/profile$i.jpeg"
                  ,callNumber: i,callIconNum: i)
          ],
        ),
      ),
    );
  }
}

Container calls ({required String callerName, required String callDate, required String callerAvatar,
  required int callNumber, required  int callIconNum}){
  return Container(
    margin: EdgeInsets.symmetric(vertical:12 ),
    child: Row(
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(40),
          child: Image.asset(callerAvatar,
            height:60 ,
            width: 60,
          fit: BoxFit.cover,),
        ),Padding(padding: EdgeInsets.only(left: 20),

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Text(callerName,style: TextStyle( //TODO make it a varible
                  fontSize: 18,
                  fontWeight: FontWeight.bold
              )),
              SizedBox(height: 8,),
              Row(
                children: [
                  // Icon(Icons.call_made,
                  //   color: Colors.green,
                  //   size: 19,
                  // )
                  callIcon( callType: callIconNum)
                  , SizedBox(
                    width: 5,
                  ),
                  Text( "("+callNumber.toString()+")"+callDate//TODO make it a varible of date ,
                    ,style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w500,
                      color: Colors.black26,
                    ),
                  )
                ],
              )
            ],
          ),
        ),
        Spacer(),
        Container(
          child:Icon(
            Icons.call_sharp,
            color: Colors.green[700],
          ),
        )

      ],
    ),
  );
}

Icon callIcon({required int callType}){
  if(callType<=3){
    return Icon(Icons.call_received,
  color: Colors.red[900],
  size: 19);
  }
    return Icon(Icons.call_made,
        color: Colors.green,
        size: 19);
  }
