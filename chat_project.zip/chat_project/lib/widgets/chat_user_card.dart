

import 'package:chat_project/models/chat_user.dart';
import 'package:chat_project/widgets/ChatsWidget.dart';
import 'package:flutter/material.dart';
import '../screens/ChatPage.dart';

class ChatUserCard extends StatefulWidget {
  final ChatUser user;
  const ChatUserCard ({super.key, required this.user});
  @override
  State<ChatUserCard> createState() => _ChatUserCardState();
}

class _ChatUserCardState extends State<ChatUserCard> {
  @override
  Widget build(BuildContext context) {
   return Card( //todo change the shape of the user card
     child:InkWell(
       onTap: () {
     Navigator.push(context, MaterialPageRoute(
         builder: (context) => ChatPage(user: widget.user)));
   },
    child: Container(
    margin: EdgeInsets.symmetric(vertical: 12),
    child: Row(
    children: [
    ClipRRect(
    borderRadius: BorderRadius.circular(40),
    child: Icon( Icons.account_circle, color: Colors.purple[800],size: 65,
      )
    // Image.asset(widget.user.image, height: 65, width: 65,
    // fit: BoxFit.cover,), //Todo can i make it a string for path

    ),
    Padding(
    padding: EdgeInsets.only(left: 20),
    child: Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
    Text(widget.user.name
    //TODO make it a varible that has he name of the person he is chatting with+ make component
    , style: TextStyle(
    fontSize: 18, fontWeight: FontWeight.bold)),
    SizedBox(
    height: 3,
    ),
    Text(widget.user.about
    //TODO make it a varible that has he chat of the person he is chatting with+ make component
    , style: TextStyle(fontSize: 15,
    fontWeight: FontWeight.w500,
    color: Colors.black26))

    ],
    ),

    ),
    Spacer()
    , Column(
    children: [
    Text("12:18PM", //TODO make it vareible
    style: TextStyle(
    color: Colors.purple[800],
    fontSize: 15,
    fontWeight: FontWeight.w500,
    ),
    ), SizedBox(
    height: 6,
    ),
    Container(
    alignment: Alignment.center,
    width: 28,
    height: 28,
    decoration: BoxDecoration(
    color: Colors.purple[800],
    borderRadius: BorderRadius.circular(20)
    ),
    child: (
    Text(
    "2",
    //TODO put a varible for the number of messages in a vhat
    style: TextStyle(
    fontWeight: FontWeight.w500,
    color: Colors.white,
    fontSize: 16
    ),

    )
    ),


    )

    ],
    )


    ],
    ),
    ),
    ));
    }
}
InkWell chatBuilderr(
    {required String chatName, required String lastMessage, required String avatar, required BuildContext context}) {
  return InkWell(
    onTap: () {
      // Navigator.push(context, MaterialPageRoute(
      //     builder: (context) => ChatPage(user: widget.user)));
    },
    child: Container(
      margin: EdgeInsets.symmetric(vertical: 12),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(40),
            child: Image.asset(avatar, height: 65, width: 65,
              fit: BoxFit.cover,), //Todo can i make it a string for path

          ),
          Padding(
            padding: EdgeInsets.only(left: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(chatName
                    //TODO make it a varible that has he name of the person he is chatting with+ make component
                    , style: TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold)),
                SizedBox(
                  height: 3,
                ),
                Text(lastMessage
                    //TODO make it a varible that has he chat of the person he is chatting with+ make component
                    , style: TextStyle(fontSize: 15,
                        fontWeight: FontWeight.w500,
                        color: Colors.black26))

              ],
            ),

          ),
          Spacer()
          , Column(
            children: [
              Text("12:18PM", //TODO make it vareible
                style: TextStyle(
                  color: Colors.purple[800],
                  fontSize: 15,
                  fontWeight: FontWeight.w500,
                ),
              ), SizedBox(
                height: 6,
              ),
              Container(
                alignment: Alignment.center,
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                    color: Colors.purple[800],
                    borderRadius: BorderRadius.circular(20)
                ),
                child: (
                    Text(
                      "2",
                      //TODO put a varible for the number of messages in a vhat
                      style: TextStyle(
                          fontWeight: FontWeight.w500,
                          color: Colors.white,
                          fontSize: 16
                      ),

                    )
                ),


              )

            ],
          )


        ],
      ),
    ),
  );}