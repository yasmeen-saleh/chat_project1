import 'package:chat_project/widgets/ChatBottomBar.dart';
import 'package:chat_project/widgets/ChatSample.dart';
import 'package:flutter/material.dart';
class ChatPage extends StatelessWidget{
  Widget build(BuildContext context){
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(65),
        child: AppBar(
          backgroundColor: Colors.purple[800],
          elevation: 0,
          leading: Padding(
            padding: EdgeInsets.only(top: 10,left: 5),
            child: InkWell(
              onTap: (){
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back, size: 25,color: Colors.white,)
            ),
          ),
          leadingWidth: 20,
          title: Padding(padding: EdgeInsets.only(top:5)
          , child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(30),
                  child: Image.asset("images/profile1.jpeg", height: 45,width: 45,
                    fit: BoxFit.cover,
                  ),
                ),
                Padding(padding: EdgeInsets.only(left: 10, top: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Programmer", style:
                      TextStyle(fontSize: 19, color: Colors.white)),
                      // SizedBox(height: ,),
                      Text("online",
                      style: TextStyle(fontSize: 15, color: Colors.white70),),


                    ],
                  ) ,
                )
              ],
            ),
          ),
          
          actions: [
            Padding(padding: EdgeInsets.only(top: 10, right: 10 ),
            child: Icon(Icons.more_vert, size: 25,color: Colors.white,),)
          ],
        ),
      ),
      body: Container(
        // decoration: BoxDecoration(
        //
        // ),//TODO if i want to add an image
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(top: 10, left: 8 , right: 8, bottom: 80),
            child: Column(
              children: [
               ChatSample(),
                ChatSample(),
                ChatSample(),
                ChatSample(),
                ChatSample(),
              ],
            ),
          ),
        ),
      ),
      bottomSheet: ChatBottomBar(),
    );
  }
}