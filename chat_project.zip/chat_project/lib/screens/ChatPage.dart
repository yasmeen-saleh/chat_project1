import 'dart:convert';
import 'dart:developer';
import 'package:chat_project/widgets/ChatBottomBar.dart';
import 'package:chat_project/widgets/ChatSample.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../Data/Api.dart';
import '../models/chat_user.dart';
import '../models/message.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
class ChatPage extends StatefulWidget{

  final ChatUser user;
  const ChatPage({super.key, required this.user});

  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  static FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<Message> list = [];
  final _textController = TextEditingController();
  Widget build(BuildContext context){
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(65),
        child: AppBar(
          backgroundColor: Colors.purple[800],
          elevation: 0,
          leading: Padding(
            padding: EdgeInsets.only(top: 10,left: 5),
            child: InkWell(
              onTap: (){
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back, size: 25,color: Colors.white,)
            ),
          ),
          leadingWidth: 20,
          title: Padding(padding: EdgeInsets.only(top:5)
          , child: Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(30),
                  child: Icon( Icons.account_circle, color: Colors.white,size: 55,
                  )
                  // Image.asset("images/profile1.jpeg", height: 45,width: 45, //todo make image change
                  //   fit: BoxFit.cover,
                  // ),
                ),
                Padding(padding: EdgeInsets.only(left: 10, top: 10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text( widget.user.name.toString() , style:
                      TextStyle(fontSize: 19, color: Colors.white)),
                      // SizedBox(height: ,),
                      Text("online",
                      style: TextStyle(fontSize: 15, color: Colors.white70),),


                    ],
                  ) ,
                )
              ],
            ),
          ),

          actions: [
            Padding(padding: EdgeInsets.only(top: 10, right: 10 ),
            child: IconButton(
              onPressed: (){
              messageStream();
              },
              icon:Icon(Icons.download_rounded, size: 25,color: Colors.white),
            )
             // ),)
            ) ],
        ),
      ),
      body:

      // Container(
      //   // decoration: BoxDecoration(
      //   //
      //   // ),//TODO if i want to add an image
      //   child:
        SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.only(top: 10, left: 8 , right: 8, bottom: 80),
            child: Column(
              children: [
                StreamBuilder(
                    stream: Api.getAllmessages(widget.user),
                    // snapshot.data?.docs.map((e) => e.id).toList() ?? []
                    builder: (context, snapshot) {
                      switch(snapshot.connectionState){
                      //data is loading
                        case ConnectionState.waiting:
                        case ConnectionState.none:
                          return const Center(child: CupertinoActivityIndicator(color: Colors.purple,),); //todo change it to match the one in the front page
                      //data is loaded
                        case ConnectionState.active:
                        case ConnectionState.done:

                          final data = snapshot.data?.docs;
                          print(Message);
                          list= data?.map((e) => Message.fromJson(e.data())).toList()??
                              [];
                          // log('Data: ${jsonEncode(data![0].data())}');
                          // list.clear();
                          // list.add(Message(msg: "yy", formId: Api.user.uid, read: "", told: "xyz", type: Type.text, sent: "12"));
                          // list.add(Message(msg: "tt", formId: "xyz", read: "", told:Api.user.uid, type:Type.text, sent: "1"));
                          // list =data?.map((e) => ChatUser.fromJson(e.data())).toList() ?? [];
                          // log('Data: ${jsonEncode( i.data())}');//todo find what is the problem
                          // list.add(i.data()['name']);//its not returnning data



                          if(list.isNotEmpty){
                            return ListView.builder(
                                itemCount: list.length,
                                // reverse: true,
                                padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
                                physics: const BouncingScrollPhysics(),
                                itemBuilder: (context , index){
                                  return ChatSample(message:list[index]);

                                  // ChatUserCard(user:list[index]);Text("not empty");
                                  // chatBuilder(chatName: "Programmer", lastMessage: "How are you? ", avatar: "images/profile.jpeg", context: context);
                                }

                            );

                          }else{
                            return Center(child: Text("Say ,Hi!👋 ", style: TextStyle(  fontSize: 20), textAlign: TextAlign.center));
                          }


                      }
                    }
                ),
              ],
            ),
          ),
        ),
        bottomSheet:ChatInput(),
    
    );
   
  }
  void messageStream() async{
    await for(var snapshot in _firestore.collection("messages").snapshots()){
      for(var message in snapshot.docs){
        print(message.data());
      }
    }
  }

      // bottomSheet;:
      Widget ChatInput(){
      return Container(
        height: 65,
        child: Row(
          children: [
            Container(
              margin: EdgeInsets.all(5),
              padding: EdgeInsets.symmetric(vertical: 5, horizontal: 15),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(20)
              ),
              child: Row(
                children: [
// Icon(Icons.)
                  SizedBox(width: 10,),
                  Container(
                    alignment: Alignment.center,
                    width:290,
                    child: Expanded(
                      child: TextField(
                        controller: _textController,
                        keyboardType: TextInputType.multiline,
                        maxLines: null,
                        style: TextStyle(
                          fontSize: 16,
                        ),
                        decoration: InputDecoration(

                          hintText: "write your message here....",
                          hintStyle: TextStyle(fontSize: 16),
                          border: InputBorder.none,

                        ),
                      ),
                    ),
                  ),
                  TextButton(onPressed:(){
                    if (_textController.text.isNotEmpty){
                      Api.sendMessage(widget.user, _textController.text);
                      _textController.text = "";
                    }
                  }, child: Text(
                    'send',

                    style: TextStyle(
                        color: Colors.deepPurple,
                        fontWeight: FontWeight.bold,
                        fontSize: 18
                    ),
                  ),
                  )

                ],
              ),
            )
          ],
        ),
      );
    }
}
