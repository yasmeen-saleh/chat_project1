import 'package:flutter/material.dart';
class SettingPage extends StatelessWidget{
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(
          color: Colors.white,
        ),
        backgroundColor: Colors.purple[800],
        title: Text("Settings",
            style: TextStyle(color: Colors.white),

        ),
      ),
      body:SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 15,vertical: 20),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.symmetric(horizontal: 12, ),
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(40),
                      child: Image.asset("images/profile2.jpeg",
                      height: 65,
                      width: 65,
                      ),
                      
                    ),
                    Padding(padding: EdgeInsets.only(left: 20),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("Programmer",
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                        ),
                        SizedBox(height: 5,)
                        ,Text("Hey There, I'm using Let's Talk",
                        style: TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w500,
                          color: Colors.black45
                        ),)
                      ],
                    ),
                    )
                  ],
                ),
              ),
              SizedBox(height: 15,),

              Divider(
                thickness: 0,

              ),
              settingTiles(title: "Account", titleIcon: Icons.key, description: "Privacy, Security, Change Email."),
              settingTiles(title: "Chats", titleIcon: Icons.message, description: "Theme , wallpapers , chat history."),
              settingTiles(title: "Notifications", titleIcon: Icons.notifications, description: "Messages , groups , & call tones."),
              settingTiles(title: "Storage and Data", titleIcon: Icons.circle_outlined, description: "Network usage, auto-download."),
              settingTiles(title: "Help Center", titleIcon: Icons.help_outline_outlined, description: "Help Center, Contact us, Privacy policy."),
              settingTiles(title: "Invite a Friend", titleIcon: Icons.people, description: " Send an invitation via SMS or email. "),
              Padding(padding: EdgeInsets.symmetric(vertical: 60),
                child: Column(
                  children: [
                    Text("from",
                    style: TextStyle(
                      fontSize: 15
                    )),Text("Yasmeen,Amira,Fatima",
                      style:TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold
                      ),)
                  ],
                ),)


            ],
          ),
       
        ),
      )

    ) ;
  }

}
Padding settingTiles({required String title, required IconData titleIcon, required String description}){
return Padding(
  padding:EdgeInsets.only(top: 5),
  child:   ListTile(
  leading: Padding(
  padding: EdgeInsets.only(top: 3),
  child: Icon(titleIcon,
  color: Colors.purple[800],),
  ),
  title: Text(
  title,
  style: TextStyle(
  fontSize: 17
  ),
  ),
  subtitle: Text(
  description,
  style: TextStyle(
  fontSize: 15,
    color: Colors.black54
  ),
  ),
  ),
);
}