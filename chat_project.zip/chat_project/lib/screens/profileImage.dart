import 'package:flutter/cupertino.dart';
import 'dart:typed_data';


import 'package:chat_project/widgets/ImageWidegt.dart';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

import '../resoures/add_data.dart';
class ProfileImage extends ChangeNotifier{

  Uint8List? image;

  void selectImageFromGallery() async{
    Uint8List img = await pickImage(ImageSource.gallery);
   // setState((){
      //_image=img;
   // });
    image= img;
    notifyListeners();
  }
  void selectImageFromCamera() async{
    Uint8List img = await pickImage(ImageSource.camera);
    //setState((){
      //_image=img;
    //});
    image= img;
    notifyListeners();
  }

  void saveProfile() async{
    String resp = await StorageData().saveData(file: image!);
  }
  change(int selected){
  if(selected ==1){
  selectImageFromGallery();
  saveProfile();
  }else{
  selectImageFromCamera();
  saveProfile();
  }
  }
}