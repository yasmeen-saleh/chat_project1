 import 'package:chat_project/widgets/CallWidget.dart';
import 'package:chat_project/widgets/ChatsWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class UserChats extends StatelessWidget{
  Widget build(BuildContext context){
    return DefaultTabController(length: 4,
        child:  Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(70),
        child: AppBar(

          backgroundColor: Colors.purple[900],
          elevation: 0,
          title: Padding(
            padding: EdgeInsets.only(top: 15),
            child: Text(
              "Let's Talk", style: TextStyle(fontSize: 21, color: Colors.white),//Todo choose one color for all of them
            ),
          ),
          actions: [
            Padding(padding: EdgeInsets.only(top: 10,right: 15),
            child:Icon(Icons.search,color: Colors.white,//Todo choose one color for all of them
          size: 28,)
            ),
            PopupMenuButton(//TODO check what are you keeping and what are you deleting
                // onSelected: (selected){
                //   if(selected ==5){
                //   Navigator.pushNamed(context, "settingsPage")
                // //   }
                // },

                padding: EdgeInsets.symmetric(vertical: 20),
                iconSize: 28,
                color: Colors.white,//Todo choose one color for all of them

                itemBuilder: (context)=>[
                  PopupMenuItem(
                    value: 1,
                      child: Text( "New Group",
                        style: TextStyle(
                            fontSize: 17,
                        fontWeight: FontWeight.w500),)
                ),
                  PopupMenuItem(
                      value: 2,
                      child: Text( "New Broadcast",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500),)
                  ),
                  PopupMenuItem(
                      value: 3,
                      child: Text( "Link Devices",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500),)
                  ),
                  PopupMenuItem(
                      value:4,
                      child: Text( "Starred Messages ",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500),)
                  ),
                  PopupMenuItem(
                      value: 5,
                      child: Text( "Settings",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500),)
                  )

                ]
            )

          ],
        ),
      ),

          body: Column(
            children: [
              Container(
            color:Colors.purple[900],
                child: TabBar(
                  isScrollable: true,
                  indicatorColor: Colors.white,
                  indicatorWeight: 4,
                  labelStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.bold ),
                  tabs: [
                    Container(
                      width: 25,
                      //tab1
                      child: Tab(
                        icon: Icon(Icons.camera_alt, color: Colors.white,),
                      ) ,
                    ),
                    Container(
                      width: 145,
                      //tab2
                      child: Tab(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("CHATS",

                            style: TextStyle( color: Colors.white),),
                            SizedBox(
                              width: 8,
                            ),
                            Container(
                              alignment: Alignment.center,
                              height: 21,
                              width: 21,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                "10",//TODO put varible for num of chats
                                style: TextStyle(
                                  color:  Colors.purple[900],
                                  fontSize: 14
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Container(

                      width: 145,
                      child: Tab(child:
                        Text("CALLS",
                            style: TextStyle( color: Colors.white)
                        ),


                      ),

                    )

                  ],
                ),

        ),
              Flexible(
                flex: 1,
                  child: TabBarView(
                    children: [
                      //tab1 camera
                      Stack(

                        children: [
                          CircleAvatar(
                            radius: 64,
                            backgroundImage: AssetImage('images/BlankProfile.png'),
                          ),
                          Positioned(child: IconButton(
                            onPressed: (){},icon:Icon(Icons.add_a_photo)
                          ),

                          )
                        ],
                      ),
                      //tab2 chatsWidget

                      ChatsWidget(),

                      //tab3 callsWidget
                      CallWidget()
                    ],
                  ))

          ],
        ) ,



    )
    );

  }

}