 import 'dart:typed_data';
import 'dart:io';
import 'package:chat_project/screens/SettingPage.dart';
import 'package:chat_project/widgets/CallWidget.dart';
import 'package:chat_project/widgets/ChatsWidget.dart';
import 'package:chat_project/widgets/ImageWidegt.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class UserChats extends StatefulWidget{
  @override
  State<UserChats> createState() => _UserChatsState();
}

class _UserChatsState extends State<UserChats> {
  Widget build(BuildContext context){
    return DefaultTabController(length: 4,
        child:  Scaffold(
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(70),
        child: AppBar(
          leading: //Todo can i make it a string for path
          BackButton(
            color: Colors.purple[800],
            //todo make sure it's take out latter
          ), //todo try to do it on the whole app
          backgroundColor: Colors.purple[800],
          elevation: 0,
          title: Padding(
            padding: EdgeInsets.only(top: 12),
            child: Text(
              "Let's Talk", style:
            TextStyle(fontSize: 22, color: Colors.white, fontWeight: FontWeight.bold),
              textAlign: TextAlign.left,//Todo choose one color for all of them
            ),
          ),
          actions: [
            Padding(padding: EdgeInsets.only(top: 10,right: 15),
            child:Icon(Icons.search,color: Colors.white,//Todo choose one color for all of them
          size: 28,)
            ),
            PopupMenuButton(//TODO check what are you keeping and what are you deleting
                onSelected: (selected){
                  if(selected ==5){
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context)=>SettingPage()));
                  }
                },

                padding: EdgeInsets.symmetric(vertical: 20),
                iconSize: 28,
                color: Colors.white,//Todo choose one color for all of them

                itemBuilder: (context)=>[
                  PopupMenuItem(
                    value: 1,
                      child: Text( "New Group",
                        style: TextStyle(
                            fontSize: 17,
                        fontWeight: FontWeight.w500),)
                ),
                  PopupMenuItem(
                      value: 2,
                      child: Text( "New Broadcast",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500),)
                  ),
                  PopupMenuItem(
                      value: 3,
                      child: Text( "Link Devices",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500),)
                  ),
                  PopupMenuItem(
                      value:4,
                      child: Text( "Starred Messages ",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500),)
                  ),
                  PopupMenuItem(
                      value: 5,
                      child: Text( "Settings",
                        style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w500),)
                  )

                ]
            )

          ],
        ),
      ),

          body: Column(
            children: [
              Container(
            color:Colors.purple[800],
                child: TabBar(
                  isScrollable: true,
                  indicatorColor: Colors.white,
                  indicatorWeight: 4,
                  labelStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.bold ),
                  tabs: [
                    Container(
                      width: 25,
                      //tab1
                      child: Tab(
                        icon: Icon(Icons.camera_alt, color: Colors.white,),
                      ) ,
                    ),
                    Container(
                      width: 145,
                      //tab2
                      child: Tab(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text("CHATS",

                            style: TextStyle( color: Colors.white),),
                            SizedBox(
                              width: 8,
                            ),
                            Container(
                              alignment: Alignment.center,
                              height: 21,
                              width: 21,
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                "10",//TODO put varible for num of chats
                                style: TextStyle(
                                  color:  Colors.purple[800],
                                  fontSize: 14
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                    Container(

                      width: 145,
                      child: Tab(child:
                        Text("CALLS",
                            style: TextStyle( color: Colors.white)
                        ),


                      ),

                    )

                  ],
                ),

        ),
              Flexible(
                flex: 1,
                  child: TabBarView(
                    children: [
                      //tab1 camera
                      Center(
                        child: Stack(

                          children: [
                            _image !=null?
                                CircleAvatar(
                                  radius: 80,
                                  backgroundImage: MemoryImage(_image!) ,

                                ):

                            CircleAvatar(
                              radius: 80,
                              backgroundImage: AssetImage('images/BlankProfile.png'),
                            ),
                            Positioned(child:
                                PopupMenuButton(
                                  icon: Icon(Icons.add_a_photo,
                                  color: Colors.purple[800],),//TODO check what are you keeping and what are you deleting
                                  onSelected: (selected){
                                    if(selected ==1){
                                      selectImageFromGallery();
                                    }else{
                                      selectImageFromCamera();
                                    }
                                  },
                                    padding: EdgeInsets.symmetric(vertical: 20),
                                    iconSize: 28,
                                    color: Colors.white,//Todo choose one color for all of them

                                    itemBuilder: (context)=>[
                                      PopupMenuItem(
                                          value: 1,
                                          child: Text( "Select From Gallery",
                                            style: TextStyle(
                                                fontSize: 17,
                                                fontWeight: FontWeight.w500),)
                                      ),
                                      PopupMenuItem(
                                          value: 2,
                                          child: Text( "Open Camera",
                                            style: TextStyle(
                                                fontSize: 17,
                                                fontWeight: FontWeight.w500),)


                                      ),
                                ]

                                ),
                              bottom: -14,
                              left: 110,
                            )
                          ],
                        ),
                      ),
                      //tab2 chatsWidget

                      ChatsWidget(),

                      //tab3 callsWidget
                      CallWidget()
                    ],
                  ))

          ],
        ) ,
          floatingActionButton: FloatingActionButton(

            onPressed: (){

            },
            backgroundColor: Colors.purple[800],
            child: Icon(Icons.message, color: Colors.white),

          ),



    )
    );

  }

  Uint8List? _image;

  void selectImageFromGallery() async{
Uint8List img = await pickImage(ImageSource.gallery);
setState((){
  _image=img;
});
_image= img;
  }
  void selectImageFromCamera() async{
    Uint8List img = await pickImage(ImageSource.camera);
    setState((){
      _image=img;
    });
    _image= img;
  }
}

