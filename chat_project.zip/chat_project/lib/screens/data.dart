import 'package:flutter/cupertino.dart';
import '../screens/ChatPage.dart';
import 'package:flutter/material.dart';

class Data extends ChangeNotifier{

  List numbersData=[10];

  display(){
   // numbersData= ChatPageState;
    notifyListeners();
  }

}