// part of 'cubit_cubit.dart';
//
// @immutable
// abstract class State {}
//
// class Initial extends State {}
