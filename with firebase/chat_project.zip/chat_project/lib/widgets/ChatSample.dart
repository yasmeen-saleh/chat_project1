import 'package:custom_clippers/custom_clippers.dart';
import 'package:flutter/material.dart';
class ChatSample extends StatelessWidget{
  Widget build(BuildContext context){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [

        chatSend(sendText: "hello "),
        chatSend(sendText: "how are you?"),
        chatReciver(recivedText: "good you"),
        chatReciver(recivedText: "hi "),
        chatSend(sendText: "how is everthing gooing with you hope every thimg is okey today "),
        chatReciver(recivedText: "How are you ?")
        
      ],
    );
  }

}

Padding chatReciver({required String recivedText}){
  return   Padding(padding: EdgeInsets.only(right: 80, top:15 ),//TODO make reciver component
    child: Container(
      child: ClipPath(
        clipper: UpperNipMessageClipperTwo( MessageType.receive),
        child: Container(
          padding: EdgeInsets.only( top: 10, bottom: 10,left: 25, right: 10),
          decoration: BoxDecoration(
              color:  Colors.deepPurple[300]
          ),
          child: Text(
            recivedText, style: TextStyle(fontSize: 17, color: Colors.white),
          ),
        ),
      ),
    ),
  );
}

Padding  chatSend({required String sendText}){
 return Padding(
   padding: const EdgeInsets.all(0),
   child: Container(
      alignment: Alignment.centerRight,
      margin: EdgeInsets.only( left: 80, bottom: 15),//TODO make sender component
      child: Container(
        child: ClipPath(
          clipper: UpperNipMessageClipperTwo( MessageType.send),
          child: Container(
            padding: EdgeInsets.only( top: 10, bottom: 10,left: 10, right: 20),
            decoration: BoxDecoration(
                color:  Colors.purple[800]
            ),
            child: Text(
              sendText, style: TextStyle(fontSize: 17, color: Colors.white),
            ),
          ),
        ),
      ),
   ),
 );
}







//TODO delete latter 
//   Padding(padding: EdgeInsets.only(right: 80),//TODO make reciver component
//     child: Container(
//       child: ClipPath(
//         clipper: UpperNipMessageClipperTwo( MessageType.receive),
//         child: Container(
//           padding: EdgeInsets.only( top: 10, bottom: 10,left: 25, right: 10),
//           decoration: BoxDecoration(
//             color:  Colors.deepPurple[300]
//           ),
//           child: Text(
//             "Hi, Developer", style: TextStyle(fontSize: 17, color: Colors.white),
//           ),
//         ),
//       ),
//     ),
//   ),
//   Container(
//     alignment: Alignment.centerRight,
//     margin: EdgeInsets.only(top: 20, left: 80, bottom: 15),//TODO make sender component
//     child: Container(
//       child: ClipPath(
//         clipper: UpperNipMessageClipperTwo( MessageType.send),
//         child: Container(
//           padding: EdgeInsets.only( top: 10, bottom: 10,left: 10, right: 20),
//           decoration: BoxDecoration(
//               color:  Colors.purple[800]
//           ),
//           child: Text(
//             "Hello, Programmer.", style: TextStyle(fontSize: 17, color: Colors.white),
//           ),
//         ),
//       ),
//     )
//     ,),
//   Padding(padding: EdgeInsets.only(right: 80),
//     child: Container(
//       margin: EdgeInsets.only(top: 20, bottom: 15),
//       child: ClipPath(
//         clipper: UpperNipMessageClipperTwo( MessageType.receive),
//         child: Container(
//           padding: EdgeInsets.only( top: 10, bottom: 10,left: 25, right: 10),
//           decoration: BoxDecoration(
//               color:  Colors.deepPurple[300]
//           ),
//           child: Text(
//             "How are you?", style: TextStyle(fontSize: 17, color: Colors.white),
//           ),
//         ),
//       ),
//     ),
//   ),