import 'package:cloud_firestore/cloud_firestore.dart';
final FirebaseFirestore firestore= FirebaseFirestore.instance;
const chatCollection = "chats";