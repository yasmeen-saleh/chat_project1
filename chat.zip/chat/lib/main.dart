//import 'dart:js';

import 'package:chat/screens/onboarding_screen.dart';
import 'package:chat/screens/welcome_screen.dart';
import 'package:chat/screens/signin_screen.dart';
import 'package:chat/screens/chat.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:chat/screens/sign_up_screen.dart';
import 'package:chat/screens/forgot_password_screen.dart';
//import 'package:chat/screens/onboarding_screen.dart;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:introduction_screen/introduction_screen.dart';
//import 'package:flutter_native_splash/flutter_native_splash.dart';

void main(){
/*Future main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Future.delayed(const Duration(seconds: 10));
  FlutterNativeSplash.remove();*/
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),

      home: const Splash(),
    );
  }
}
class Splash extends StatefulWidget{
  const Splash({Key? key}) : super(key: key);

  _SplashState createState() => _SplashState();
 }

class _SplashState extends State<Splash> {

  @override
  void initState() {
    // TODO: implement initState
   super.initState();
    Future.delayed(const Duration(seconds: 3),(){
      Navigator.push(context as BuildContext,MaterialPageRoute(
          builder: (context)=> OnboardingScreen()));
  });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            //Image.asset('images/1.png',height: 130,),
            Icon(Icons.mark_unread_chat_alt, size: 170,
                color: Colors.purple),
            const SizedBox(height: 30,),
            /*if( Platform.isDefinedAndNotNull)
              CupertinoActivityIndicator(
                radius: 20,
              )
            else*/
              const CupertinoActivityIndicator(
                color: Colors.purple,
              )
          ],
        ),
      ),
    );
  }
}



