import 'package:flutter/material.dart';
import 'package:chat/widgets/my_button.dart';
import 'package:chat/screens/signin_screen.dart';
import 'package:chat/screens/sign_up_screen.dart';
class WelcomeScreen extends StatefulWidget {
  const WelcomeScreen({super.key});

  @override
  State<WelcomeScreen> createState() => _WelcomeScreenState();
}

class _WelcomeScreenState extends State<WelcomeScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

    backgroundColor: Colors.white,

    body: Padding(

    padding: const EdgeInsets.symmetric(horizontal: 24),

    child: Column(

    mainAxisAlignment: MainAxisAlignment.center,

    crossAxisAlignment: CrossAxisAlignment.stretch,

    children:[

    Column(

    children: [

    Container(

    height: 180,

    child:Icon(Icons.mark_unread_chat_alt_outlined, size: 170, color: Colors.purple[600],) ,

    ), // Container

    Text(

    "Let's Talk",


    style: TextStyle(

    fontSize: 40, fontWeight: FontWeight.w900,

    color: Colors.purple,
    ),
    ),
    ],
    ),
    SizedBox (height: 30),
      InkWell(
          onTap: (){Navigator.push(context,MaterialPageRoute(
              builder: (context)=>SignInScreen()));},
          child: Container(
            height: 50,
            decoration: BoxDecoration(
                color: Colors.purple,
                borderRadius: BorderRadius.circular(5)
            ),
            child: Center(
              child: Text(
                'Sign In',
                style: TextStyle(color: Colors.white,fontSize: 20,
                    fontWeight: FontWeight.bold),
              ),
            ),
          )
//],

      ),
      SizedBox (height: 30),
     InkWell(
        //  color:Colors.purple!,


      //   title: 'sign up',)
     onTap: (){Navigator.push(context,MaterialPageRoute(
         builder: (context)=>SignUpScreen()));},
       child: Container(
         height: 50,
         decoration: BoxDecoration(
             color: Colors.purple,
             borderRadius: BorderRadius.circular(5)
         ),
      child: Center(
        child: Text(
          'Sign Up',
          style: TextStyle(color: Colors.white,fontSize: 20,
              fontWeight: FontWeight.bold),
        ),
      ),
    )


//],

    ),
    ] ),),
    );
  }
}
